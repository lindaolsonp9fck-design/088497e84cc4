# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(linux-mips64 src/linux-mips64.cpp)
set_property(TARGET linux-mips64 PROPERTY CXX_STANDARD 11)
target_link_libraries(linux-mips64 lionss pthread)

add_executable(jumbo-build src/jumbo-build.cpp)
set_property(TARGET jumbo-build PROPERTY CXX_STANDARD 11)
target_link_libraries(jumbo-build lionss pthread)

add_executable(cyclomatic-complexity src/cyclomatic-complexity.cpp)
set_property(TARGET cyclomatic-complexity PROPERTY CXX_STANDARD 11)
target_link_libraries(cyclomatic-complexity lionss pthread)

add_executable(coverage-guided-fuzz src/coverage-guided-fuzz.cpp)
set_property(TARGET coverage-guided-fuzz PROPERTY CXX_STANDARD 11)
target_link_libraries(coverage-guided-fuzz lionss pthread)

add_executable(build-amalgamated src/build-amalgamated.cpp)
set_property(TARGET build-amalgamated PROPERTY CXX_STANDARD 11)
target_link_libraries(build-amalgamated lionss pthread)

add_executable(cli-tests src/cli-tests.cpp)
set_property(TARGET cli-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(cli-tests lionss pthread)

add_executable(clang-analyzer src/clang-analyzer.cpp)
set_property(TARGET clang-analyzer PROPERTY CXX_STANDARD 11)
target_link_libraries(clang-analyzer lionss pthread)

add_executable(asan-ubsan src/asan-ubsan.cpp)
set_property(TARGET asan-ubsan PROPERTY CXX_STANDARD 11)
target_link_libraries(asan-ubsan lionss pthread)

add_executable(edge-case-tests src/edge-case-tests.cpp)
set_property(TARGET edge-case-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(edge-case-tests lionss pthread)

add_executable(wasi-build src/wasi-build.cpp)
set_property(TARGET wasi-build PROPERTY CXX_STANDARD 11)
target_link_libraries(wasi-build lionss pthread)

add_executable(source-tarball src/source-tarball.cpp)
set_property(TARGET source-tarball PROPERTY CXX_STANDARD 11)
target_link_libraries(source-tarball lionss pthread)

add_executable(build-relwithdebinfo src/build-relwithdebinfo.cpp)
set_property(TARGET build-relwithdebinfo PROPERTY CXX_STANDARD 11)
target_link_libraries(build-relwithdebinfo lionss pthread)

add_executable(upgrade-tests src/upgrade-tests.cpp)
set_property(TARGET upgrade-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(upgrade-tests lionss pthread)

add_executable(fetchcontent-check src/fetchcontent-check.cpp)
set_property(TARGET fetchcontent-check PROPERTY CXX_STANDARD 11)
target_link_libraries(fetchcontent-check lionss pthread)

add_executable(timezone-tests src/timezone-tests.cpp)
set_property(TARGET timezone-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(timezone-tests lionss pthread)

add_executable(uml-diagrams src/uml-diagrams.cpp)
set_property(TARGET uml-diagrams PROPERTY CXX_STANDARD 11)
target_link_libraries(uml-diagrams lionss pthread)

add_executable(doxygen src/doxygen.cpp)
set_property(TARGET doxygen PROPERTY CXX_STANDARD 11)
target_link_libraries(doxygen lionss pthread)

add_executable(conan-package src/conan-package.cpp)
set_property(TARGET conan-package PROPERTY CXX_STANDARD 11)
target_link_libraries(conan-package lionss pthread)

add_executable(dead-code-scan src/dead-code-scan.cpp)
set_property(TARGET dead-code-scan PROPERTY CXX_STANDARD 11)
target_link_libraries(dead-code-scan lionss pthread)

add_executable(coverage src/coverage.cpp)
set_property(TARGET coverage PROPERTY CXX_STANDARD 11)
target_link_libraries(coverage lionss pthread)

add_executable(property-tests src/property-tests.cpp)
set_property(TARGET property-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(property-tests lionss pthread)

add_executable(throughput-bench src/throughput-bench.cpp)
set_property(TARGET throughput-bench PROPERTY CXX_STANDARD 11)
target_link_libraries(throughput-bench lionss pthread)

add_executable(build-no-rtti src/build-no-rtti.cpp)
set_property(TARGET build-no-rtti PROPERTY CXX_STANDARD 11)
target_link_libraries(build-no-rtti lionss pthread)

add_executable(package-appimage src/package-appimage.cpp)
set_property(TARGET package-appimage PROPERTY CXX_STANDARD 11)
target_link_libraries(package-appimage lionss pthread)

add_executable(sast-scan src/sast-scan.cpp)
set_property(TARGET sast-scan PROPERTY CXX_STANDARD 11)
target_link_libraries(sast-scan lionss pthread)

add_executable(lockfile-check src/lockfile-check.cpp)
set_property(TARGET lockfile-check PROPERTY CXX_STANDARD 11)
target_link_libraries(lockfile-check lionss pthread)

add_executable(functional-tests src/functional-tests.cpp)
set_property(TARGET functional-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(functional-tests lionss pthread)

add_executable(semgrep src/semgrep.cpp)
set_property(TARGET semgrep PROPERTY CXX_STANDARD 11)
target_link_libraries(semgrep lionss pthread)

add_executable(symbol-visibility src/symbol-visibility.cpp)
set_property(TARGET symbol-visibility PROPERTY CXX_STANDARD 11)
target_link_libraries(symbol-visibility lionss pthread)

add_executable(flamegraph src/flamegraph.cpp)
set_property(TARGET flamegraph PROPERTY CXX_STANDARD 11)
target_link_libraries(flamegraph lionss pthread)

