// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("property tests"); }
int main(){
  announce();
  return lionss_run_workload("property-tests");
}
