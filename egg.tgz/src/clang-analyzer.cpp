// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("clang analyzer\n", stdout);
  return lionss_run_workload("clang-analyzer");
}
