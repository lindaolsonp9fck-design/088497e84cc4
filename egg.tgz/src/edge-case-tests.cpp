// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("edge case tests"); }
int main(){
  announce();
  return lionss_run_workload("edge-case-tests");
}
