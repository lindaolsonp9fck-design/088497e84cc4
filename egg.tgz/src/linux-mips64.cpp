// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("linux mips64\n", stdout);
  return lionss_run_workload("linux-mips64");
}
