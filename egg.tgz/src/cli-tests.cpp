// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("cli tests"); }
int main(){
  announce();
  return lionss_run_workload("cli-tests");
}
